const express = require('express');
const router = express.Router();
const routeController = require('../controllers/routeController');
const auth = require('../middleware/auth');

/**
 * Rutas para cálculo de rutas usando OpenRouteService
 * Alternativa gratuita a HERE Maps sin tarjeta de crédito
 */

// Rutas públicas (no requieren autenticación)

/**
 * POST /api/routes/calculate
 * Calcular ruta para camiones
 */
router.post('/calculate', routeController.calculateRoute);

/**
 * GET /api/routes/geocode
 * Geocodificar dirección a coordenadas
 * Query params: address, country (opcional), limit (opcional)
 */
router.get('/geocode', routeController.geocodeAddress);

/**
 * GET /api/routes/reverse-geocode
 * Geocodificación inversa (coordenadas a dirección)
 * Query params: lat, lng
 */
router.get('/reverse-geocode', routeController.reverseGeocode);

/**
 * POST /api/routes/isochrone
 * Calcular isócrona (área alcanzable en tiempo determinado)
 */
router.post('/isochrone', routeController.calculateIsochrone);

/**
 * GET /api/routes/status
 * Verificar estado de la API de OpenRouteService
 */
router.get('/status', routeController.checkApiStatus);

// Rutas protegidas (requieren autenticación)

/**
 * POST /api/routes/save
 * Guardar ruta calculada
 */
router.post('/save', auth, routeController.saveRoute);

/**
 * GET /api/routes/my-routes
 * Obtener rutas guardadas del usuario
 * Query params: page (opcional), limit (opcional)
 */
router.get('/my-routes', auth, routeController.getUserRoutes);

/**
 * DELETE /api/routes/:routeId
 * Eliminar ruta guardada
 */
router.delete('/:routeId', auth, routeController.deleteRoute);

module.exports = router;

