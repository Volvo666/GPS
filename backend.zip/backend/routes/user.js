const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// Ruta para registro de usuarios
router.post('/register', userController.register);

// Ruta para inicio de sesión
router.post('/login', userController.login);

// Ruta para obtener perfil de usuario
router.get('/profile', userController.getProfile);

// Ruta para actualizar perfil de usuario
router.put('/profile', userController.updateProfile);

// Ruta para añadir un vehículo
router.post('/vehicle', userController.addVehicle);

// Ruta para establecer un vehículo como predeterminado
router.put('/default-vehicle', userController.setDefaultVehicle);

module.exports = router;

