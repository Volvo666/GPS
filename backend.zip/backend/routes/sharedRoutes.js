const express = require('express');
const router = express.Router();
const SharedRouteController = require('../controllers/sharedRouteController');
const auth = require('../middleware/auth');

/**
 * Rutas para funcionalidad de compartir rutas en tiempo real
 */

// Rutas protegidas (requieren autenticación)

/**
 * @route   POST /api/shared-routes
 * @desc    Crear una nueva ruta compartida
 * @access  Private
 */
router.post('/', auth, SharedRouteController.createSharedRoute);

/**
 * @route   GET /api/shared-routes
 * @desc    Obtener rutas compartidas del usuario
 * @access  Private
 */
router.get('/', auth, SharedRouteController.getUserSharedRoutes);

/**
 * @route   PUT /api/shared-routes/:shareId/location
 * @desc    Actualizar ubicación de una ruta compartida
 * @access  Private
 */
router.put('/:shareId/location', auth, SharedRouteController.updateLocation);

/**
 * @route   PUT /api/shared-routes/:shareId/status
 * @desc    Actualizar estado de una ruta compartida
 * @access  Private
 */
router.put('/:shareId/status', auth, SharedRouteController.updateRouteStatus);

/**
 * @route   PUT /api/shared-routes/:shareId/privacy
 * @desc    Actualizar configuración de privacidad
 * @access  Private
 */
router.put('/:shareId/privacy', auth, SharedRouteController.updatePrivacySettings);

/**
 * @route   POST /api/shared-routes/:shareId/viewers
 * @desc    Añadir viewer permitido
 * @access  Private
 */
router.post('/:shareId/viewers', auth, SharedRouteController.addAllowedViewer);

/**
 * @route   DELETE /api/shared-routes/:shareId
 * @desc    Eliminar una ruta compartida
 * @access  Private
 */
router.delete('/:shareId', auth, SharedRouteController.deleteSharedRoute);

// Rutas públicas (no requieren autenticación)

/**
 * @route   GET /api/shared-routes/:shareId
 * @desc    Obtener información de una ruta compartida (público)
 * @access  Public
 */
router.get('/:shareId', SharedRouteController.getSharedRoute);

module.exports = router;

