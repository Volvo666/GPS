const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config();

// Clave de API de HERE Maps
const API_KEY = process.env.HERE_API_KEY;

// URLs base para las APIs de HERE Maps
const ROUTING_API_URL = 'https://router.hereapi.com/v8/routes';
const GEOCODING_API_URL = 'https://geocode.search.hereapi.com/v1/geocode';
const REVERSE_GEOCODING_API_URL = 'https://revgeocode.search.hereapi.com/v1/revgeocode';

/**
 * Servicio para interactuar con la API de HERE Maps
 */
class HereMapService {
  /**
   * Calcula una ruta para camiones entre dos puntos
   * @param {Object} origin - Coordenadas de origen {lat, lng}
   * @param {Object} destination - Coordenadas de destino {lat, lng}
   * @param {Array} waypoints - Array de waypoints intermedios [{lat, lng}]
   * @param {Object} vehicleParams - Parámetros del vehículo (altura, anchura, peso, etc.)
   * @param {Object} options - Opciones adicionales (evitar peajes, etc.)
   * @returns {Promise} - Promesa con los datos de la ruta
   */
  async calculateTruckRoute(origin, destination, waypoints = [], vehicleParams = {}, options = {}) {
    try {
      // Construir los parámetros de la ruta
      const transportMode = 'truck';
      const originParam = `${origin.lat},${origin.lng}`;
      const destinationParam = `${destination.lat},${destination.lng}`;
      
      // Construir waypoints si existen
      let waypointsParam = '';
      if (waypoints.length > 0) {
        waypointsParam = waypoints.map(wp => `&via=${wp.lat},${wp.lng}`).join('');
      }
      
      // Construir parámetros del vehículo
      const vehicleParamsArray = [];
      if (vehicleParams.height) vehicleParamsArray.push(`height=${vehicleParams.height}`);
      if (vehicleParams.width) vehicleParamsArray.push(`width=${vehicleParams.width}`);
      if (vehicleParams.length) vehicleParamsArray.push(`length=${vehicleParams.length}`);
      if (vehicleParams.weight) vehicleParamsArray.push(`limitedWeight=${vehicleParams.weight}`);
      if (vehicleParams.axleCount) vehicleParamsArray.push(`axleCount=${vehicleParams.axleCount}`);
      
      const vehicleParamsString = vehicleParamsArray.length > 0 
        ? `&truck[${vehicleParamsArray.join('&truck[')}]` 
        : '';
      
      // Construir opciones adicionales
      const avoidFeaturesArray = [];
      if (options.avoidTolls) avoidFeaturesArray.push('tollRoad');
      if (options.avoidHighways) avoidFeaturesArray.push('controlledAccessHighway');
      
      const avoidFeaturesString = avoidFeaturesArray.length > 0 
        ? `&avoid[features]=${avoidFeaturesArray.join(',')}` 
        : '';
      
      // Construir la URL completa
      const url = `${ROUTING_API_URL}?transportMode=${transportMode}&origin=${originParam}&destination=${destinationParam}${waypointsParam}${vehicleParamsString}${avoidFeaturesString}&return=polyline,summary,actions,instructions&apiKey=${API_KEY}`;
      
      // Realizar la petición
      const response = await axios.get(url);
      
      // Procesar y devolver los datos de la ruta
      if (response.data && response.data.routes && response.data.routes.length > 0) {
        const route = response.data.routes[0];
        return {
          distance: route.sections[0].summary.length,
          duration: route.sections[0].summary.duration,
          polyline: route.sections[0].polyline,
          instructions: route.sections[0].actions,
          bounds: route.sections[0].boundingBox
        };
      } else {
        throw new Error('No se encontró ninguna ruta');
      }
    } catch (error) {
      console.error('Error al calcular la ruta:', error);
      throw error;
    }
  }

  /**
   * Geocodifica una dirección para obtener coordenadas
   * @param {String} address - Dirección a geocodificar
   * @returns {Promise} - Promesa con las coordenadas
   */
  async geocodeAddress(address) {
    try {
      const url = `${GEOCODING_API_URL}?q=${encodeURIComponent(address)}&apiKey=${API_KEY}`;
      const response = await axios.get(url);
      
      if (response.data && response.data.items && response.data.items.length > 0) {
        const location = response.data.items[0].position;
        return {
          lat: location.lat,
          lng: location.lng,
          address: response.data.items[0].address.label
        };
      } else {
        throw new Error('No se encontraron coordenadas para la dirección proporcionada');
      }
    } catch (error) {
      console.error('Error al geocodificar la dirección:', error);
      throw error;
    }
  }

  /**
   * Realiza geocodificación inversa para obtener una dirección a partir de coordenadas
   * @param {Object} coordinates - Coordenadas {lat, lng}
   * @returns {Promise} - Promesa con la dirección
   */
  async reverseGeocode(coordinates) {
    try {
      const url = `${REVERSE_GEOCODING_API_URL}?at=${coordinates.lat},${coordinates.lng}&apiKey=${API_KEY}`;
      const response = await axios.get(url);
      
      if (response.data && response.data.items && response.data.items.length > 0) {
        return {
          address: response.data.items[0].address.label,
          city: response.data.items[0].address.city,
          country: response.data.items[0].address.countryName
        };
      } else {
        throw new Error('No se encontró ninguna dirección para las coordenadas proporcionadas');
      }
    } catch (error) {
      console.error('Error al realizar la geocodificación inversa:', error);
      throw error;
    }
  }

  /**
   * Busca áreas de descanso cercanas a una ubicación
   * @param {Object} coordinates - Coordenadas {lat, lng}
   * @param {Number} radius - Radio de búsqueda en metros
   * @returns {Promise} - Promesa con las áreas de descanso encontradas
   */
  async findRestAreas(coordinates, radius = 5000) {
    // Esta función se implementará más adelante cuando tengamos acceso a la API de Places de HERE
    // Por ahora, devolvemos un mock
    return [
      {
        id: 'rest-area-1',
        name: 'Área de Servicio Norte',
        coordinates: {
          lat: coordinates.lat + 0.01,
          lng: coordinates.lng + 0.01
        },
        distance: 1200,
        facilities: ['parking', 'restaurant', 'fuel', 'shower']
      },
      {
        id: 'rest-area-2',
        name: 'Área de Descanso Este',
        coordinates: {
          lat: coordinates.lat - 0.01,
          lng: coordinates.lng + 0.02
        },
        distance: 2500,
        facilities: ['parking', 'toilet']
      }
    ];
  }
}

module.exports = new HereMapService();

