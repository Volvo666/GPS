const axios = require('axios');

/**
 * Servicio para interactuar con OpenRouteService API
 * Alternativa gratuita a HERE Maps sin requerir tarjeta de crédito
 */
class OpenRouteService {
  constructor() {
    this.baseURL = 'https://api.openrouteservice.org/v2';
    this.apiKey = process.env.OPENROUTE_API_KEY || 'demo'; // Usar variable de entorno
  }

  /**
   * Calcular ruta para camiones
   * @param {Object} origin - Coordenadas de origen {lat, lng}
   * @param {Object} destination - Coordenadas de destino {lat, lng}
   * @param {Object} vehicleParams - Parámetros del vehículo
   * @returns {Promise<Object>} - Datos de la ruta calculada
   */
  async calculateTruckRoute(origin, destination, vehicleParams = {}) {
    try {
      const {
        height = 4.2,
        width = 2.5,
        length = 16.5,
        weight = 40,
        axleCount = 5
      } = vehicleParams;

      const requestData = {
        coordinates: [
          [origin.lng, origin.lat],
          [destination.lng, destination.lat]
        ],
        format: 'json',
        profile: 'driving-hgv', // Heavy Goods Vehicle profile
        options: {
          vehicle_type: 'hgv',
          restrictions: {
            height: height,
            width: width,
            length: length,
            weight: weight,
            axles: axleCount
          }
        },
        instructions: true,
        geometry: true,
        elevation: false
      };

      const response = await axios.post(
        `${this.baseURL}/directions/driving-hgv`,
        requestData,
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          timeout: 30000 // 30 segundos timeout
        }
      );

      if (response.data && response.data.routes && response.data.routes.length > 0) {
        const route = response.data.routes[0];
        
        return {
          success: true,
          route: {
            distance: route.summary.distance, // en metros
            duration: route.summary.duration, // en segundos
            geometry: route.geometry, // coordenadas de la ruta
            instructions: this.formatInstructions(route.segments),
            bbox: route.bbox, // bounding box
            warnings: route.warnings || [],
            extras: route.extras || {}
          }
        };
      } else {
        throw new Error('No se encontró una ruta válida');
      }

    } catch (error) {
      console.error('Error calculando ruta con OpenRouteService:', error.message);
      
      if (error.response) {
        const status = error.response.status;
        const message = error.response.data?.error?.message || error.message;
        
        if (status === 401) {
          throw new Error('API key inválida para OpenRouteService');
        } else if (status === 403) {
          throw new Error('Límite de requests excedido para OpenRouteService');
        } else if (status === 404) {
          throw new Error('No se pudo encontrar una ruta entre los puntos especificados');
        } else if (status === 422) {
          throw new Error('Parámetros de vehículo inválidos');
        } else {
          throw new Error(`Error de OpenRouteService: ${message}`);
        }
      } else {
        throw new Error(`Error de conexión con OpenRouteService: ${error.message}`);
      }
    }
  }

  /**
   * Geocodificación - convertir dirección a coordenadas
   * @param {string} address - Dirección a geocodificar
   * @param {Object} options - Opciones adicionales
   * @returns {Promise<Object>} - Coordenadas y información de la dirección
   */
  async geocode(address, options = {}) {
    try {
      const params = {
        api_key: this.apiKey,
        text: address,
        size: options.limit || 5,
        layers: options.layers || 'address,venue,street',
        'boundary.country': options.country || 'ES,FR,DE,IT,PT,NL,BE,AT,CH,PL,CZ,HU,SK,SI,HR,RO,BG,GR,LT,LV,EE,FI,SE,DK,NO,IE,LU,MT,CY'
      };

      if (options.bbox) {
        params['boundary.rect.min_lat'] = options.bbox.minLat;
        params['boundary.rect.min_lon'] = options.bbox.minLng;
        params['boundary.rect.max_lat'] = options.bbox.maxLat;
        params['boundary.rect.max_lon'] = options.bbox.maxLng;
      }

      const response = await axios.get(`${this.baseURL}/geocode/search`, {
        params,
        timeout: 15000
      });

      if (response.data && response.data.features && response.data.features.length > 0) {
        const results = response.data.features.map(feature => ({
          address: feature.properties.label,
          coordinates: {
            lat: feature.geometry.coordinates[1],
            lng: feature.geometry.coordinates[0]
          },
          confidence: feature.properties.confidence || 1,
          country: feature.properties.country,
          region: feature.properties.region,
          locality: feature.properties.locality,
          postalCode: feature.properties.postalcode
        }));

        return {
          success: true,
          results
        };
      } else {
        return {
          success: false,
          results: [],
          message: 'No se encontraron resultados para la dirección especificada'
        };
      }

    } catch (error) {
      console.error('Error en geocodificación con OpenRouteService:', error.message);
      throw new Error(`Error de geocodificación: ${error.message}`);
    }
  }

  /**
   * Geocodificación inversa - convertir coordenadas a dirección
   * @param {number} lat - Latitud
   * @param {number} lng - Longitud
   * @returns {Promise<Object>} - Información de la dirección
   */
  async reverseGeocode(lat, lng) {
    try {
      const response = await axios.get(`${this.baseURL}/geocode/reverse`, {
        params: {
          api_key: this.apiKey,
          'point.lat': lat,
          'point.lon': lng,
          size: 1
        },
        timeout: 15000
      });

      if (response.data && response.data.features && response.data.features.length > 0) {
        const feature = response.data.features[0];
        
        return {
          success: true,
          address: feature.properties.label,
          details: {
            country: feature.properties.country,
            region: feature.properties.region,
            locality: feature.properties.locality,
            street: feature.properties.street,
            postalCode: feature.properties.postalcode
          }
        };
      } else {
        return {
          success: false,
          message: 'No se encontró información para las coordenadas especificadas'
        };
      }

    } catch (error) {
      console.error('Error en geocodificación inversa:', error.message);
      throw new Error(`Error de geocodificación inversa: ${error.message}`);
    }
  }

  /**
   * Calcular isócrona (área alcanzable en un tiempo determinado)
   * @param {Object} center - Coordenadas centrales {lat, lng}
   * @param {number} timeMinutes - Tiempo en minutos
   * @param {Object} vehicleParams - Parámetros del vehículo
   * @returns {Promise<Object>} - Polígono de isócrona
   */
  async calculateIsochrone(center, timeMinutes, vehicleParams = {}) {
    try {
      const requestData = {
        locations: [[center.lng, center.lat]],
        range: [timeMinutes * 60], // convertir a segundos
        range_type: 'time',
        profile: 'driving-hgv',
        options: {
          vehicle_type: 'hgv',
          restrictions: {
            height: vehicleParams.height || 4.2,
            width: vehicleParams.width || 2.5,
            length: vehicleParams.length || 16.5,
            weight: vehicleParams.weight || 40
          }
        }
      };

      const response = await axios.post(
        `${this.baseURL}/isochrones/driving-hgv`,
        requestData,
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          },
          timeout: 30000
        }
      );

      if (response.data && response.data.features && response.data.features.length > 0) {
        return {
          success: true,
          isochrone: response.data.features[0].geometry
        };
      } else {
        throw new Error('No se pudo calcular la isócrona');
      }

    } catch (error) {
      console.error('Error calculando isócrona:', error.message);
      throw new Error(`Error de isócrona: ${error.message}`);
    }
  }

  /**
   * Formatear instrucciones de navegación
   * @private
   */
  formatInstructions(segments) {
    const instructions = [];
    
    if (segments && Array.isArray(segments)) {
      segments.forEach(segment => {
        if (segment.steps && Array.isArray(segment.steps)) {
          segment.steps.forEach(step => {
            if (step.instruction) {
              instructions.push({
                instruction: step.instruction,
                distance: step.distance,
                duration: step.duration,
                type: step.type,
                name: step.name || ''
              });
            }
          });
        }
      });
    }

    return instructions;
  }

  /**
   * Verificar estado de la API
   * @returns {Promise<Object>} - Estado de la API
   */
  async checkApiStatus() {
    try {
      // Hacer una petición simple para verificar conectividad
      const response = await axios.get(`${this.baseURL}/geocode/search`, {
        params: {
          api_key: this.apiKey,
          text: 'Madrid',
          size: 1
        },
        timeout: 10000
      });

      return {
        success: true,
        status: 'API funcionando correctamente',
        remainingQuota: response.headers['x-ratelimit-remaining'] || 'No disponible'
      };

    } catch (error) {
      return {
        success: false,
        status: 'Error de conectividad con la API',
        error: error.message
      };
    }
  }
}

module.exports = new OpenRouteService();

