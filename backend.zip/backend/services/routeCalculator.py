"""
Servicio para el cálculo de rutas para camiones considerando tiempos de conducción y descanso.
"""

import math
import datetime
from typing import Dict, List, Tuple, Optional, Any

class TruckRouteCalculator:
    """
    Calculadora de rutas para camiones que considera tiempos de conducción y descanso
    según la normativa europea.
    """
    
    # Constantes para tiempos de conducción y descanso (en segundos)
    MAX_CONTINUOUS_DRIVING = 4.5 * 3600  # 4.5 horas
    REQUIRED_BREAK = 45 * 60  # 45 minutos
    MAX_DAILY_DRIVING = 9 * 3600  # 9 horas (puede extenderse a 10 horas dos veces por semana)
    MIN_DAILY_REST = 11 * 3600  # 11 horas
    
    # Límites de velocidad por defecto por tipo de vía (en km/h)
    DEFAULT_SPEED_LIMITS = {
        'motorway': 80,  # Autopista
        'trunk': 80,     # Vía rápida
        'primary': 70,   # Carretera principal
        'secondary': 60, # Carretera secundaria
        'tertiary': 50,  # Carretera terciaria
        'residential': 50,  # Vía urbana
        'service': 30,   # Vía de servicio
        'default': 60    # Valor por defecto
    }
    
    # Límites de velocidad por país (sobreescriben los valores por defecto)
    COUNTRY_SPEED_LIMITS = {
        'ES': {  # España
            'motorway': 90,
            'trunk': 80,
            'primary': 80,
            'residential': 50
        },
        'FR': {  # Francia
            'motorway': 90,
            'trunk': 80,
            'primary': 80,
            'residential': 50
        },
        'DE': {  # Alemania
            'motorway': 80,
            'trunk': 60,
            'primary': 60,
            'residential': 50
        },
        # Añadir más países según sea necesario
    }
    
    def __init__(self, api_service=None):
        """
        Inicializa la calculadora de rutas.
        
        Args:
            api_service: Servicio para interactuar con la API de mapas externa
        """
        self.api_service = api_service
    
    def calculate_route(self, 
                        origin: Dict[str, float], 
                        destination: Dict[str, float], 
                        vehicle_params: Dict[str, Any],
                        departure_time: Optional[datetime.datetime] = None,
                        waypoints: List[Dict[str, float]] = None,
                        options: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Calcula una ruta para camiones considerando tiempos de conducción y descanso.
        
        Args:
            origin: Coordenadas de origen {lat, lng}
            destination: Coordenadas de destino {lat, lng}
            vehicle_params: Parámetros del vehículo (altura, anchura, peso, etc.)
            departure_time: Hora de salida (por defecto, hora actual)
            waypoints: Lista de puntos intermedios [{lat, lng}]
            options: Opciones adicionales para el cálculo de la ruta
            
        Returns:
            Diccionario con la información de la ruta calculada
        """
        # Establecer hora de salida
        if departure_time is None:
            departure_time = datetime.datetime.now()
        
        # Obtener la ruta base desde la API externa
        base_route = self._get_base_route(origin, destination, vehicle_params, waypoints, options)
        
        if not base_route:
            return {
                'status': 'error',
                'message': 'No se pudo calcular la ruta base'
            }
        
        # Calcular tiempos considerando descansos
        enhanced_route = self._enhance_route_with_breaks(base_route, departure_time, vehicle_params)
        
        return enhanced_route
    
    def _get_base_route(self, 
                       origin: Dict[str, float], 
                       destination: Dict[str, float], 
                       vehicle_params: Dict[str, Any],
                       waypoints: List[Dict[str, float]] = None,
                       options: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Obtiene la ruta base desde la API externa.
        
        En una implementación real, esta función llamaría a la API de HERE Maps
        o similar para obtener la ruta base. Para este ejemplo, simularemos una respuesta.
        """
        # Simulación de una respuesta de API para desarrollo
        # En una implementación real, esto vendría de la API de HERE Maps
        
        # Distancia simulada entre origen y destino (en metros)
        distance = 500000  # 500 km
        
        # Velocidad media estimada (en m/s)
        avg_speed_kmh = 70  # 70 km/h
        avg_speed_ms = avg_speed_kmh / 3.6  # Convertir a m/s
        
        # Tiempo base sin considerar descansos (en segundos)
        base_duration = distance / avg_speed_ms
        
        # Crear segmentos de ruta simulados
        segments = []
        segment_count = 5
        segment_distance = distance / segment_count
        segment_duration = base_duration / segment_count
        
        for i in range(segment_count):
            segment = {
                'distance': segment_distance,
                'duration': segment_duration,
                'road_type': 'motorway' if i % 2 == 0 else 'primary',
                'country_code': 'ES' if i < segment_count / 2 else 'FR',
                'start_point': {
                    'lat': origin['lat'] + (destination['lat'] - origin['lat']) * i / segment_count,
                    'lng': origin['lng'] + (destination['lng'] - origin['lng']) * i / segment_count
                },
                'end_point': {
                    'lat': origin['lat'] + (destination['lat'] - origin['lat']) * (i + 1) / segment_count,
                    'lng': origin['lng'] + (destination['lng'] - origin['lng']) * (i + 1) / segment_count
                }
            }
            segments.append(segment)
        
        # Crear ruta base
        base_route = {
            'status': 'success',
            'distance': distance,
            'duration': base_duration,
            'segments': segments,
            'origin': origin,
            'destination': destination
        }
        
        return base_route
    
    def _enhance_route_with_breaks(self, 
                                  base_route: Dict[str, Any], 
                                  departure_time: datetime.datetime,
                                  vehicle_params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Mejora la ruta base añadiendo paradas para descansos según la normativa.
        
        Args:
            base_route: Ruta base calculada
            departure_time: Hora de salida
            vehicle_params: Parámetros del vehículo
            
        Returns:
            Ruta mejorada con información de descansos
        """
        segments = base_route['segments']
        
        # Inicializar variables para seguimiento de tiempos
        current_time = departure_time
        continuous_driving_time = 0
        daily_driving_time = 0
        last_break_time = departure_time
        last_daily_rest_time = departure_time
        
        # Lista para almacenar los descansos requeridos
        required_breaks = []
        
        # Recorrer los segmentos y calcular descansos
        accumulated_distance = 0
        for i, segment in enumerate(segments):
            segment_duration = segment['duration']
            segment_distance = segment['distance']
            
            # Verificar si se necesita un descanso antes de este segmento
            if continuous_driving_time + segment_duration > self.MAX_CONTINUOUS_DRIVING:
                # Añadir un descanso
                break_location = segments[i-1]['end_point'] if i > 0 else segments[0]['start_point']
                break_start_time = current_time
                break_end_time = break_start_time + datetime.timedelta(seconds=self.REQUIRED_BREAK)
                
                required_breaks.append({
                    'type': 'break',
                    'location': break_location,
                    'start_time': break_start_time,
                    'end_time': break_end_time,
                    'duration': self.REQUIRED_BREAK,
                    'accumulated_distance': accumulated_distance
                })
                
                # Actualizar tiempos
                current_time = break_end_time
                continuous_driving_time = 0
                last_break_time = break_end_time
            
            # Verificar si se necesita un descanso diario
            if daily_driving_time + segment_duration > self.MAX_DAILY_DRIVING:
                # Añadir un descanso diario
                rest_location = segments[i-1]['end_point'] if i > 0 else segments[0]['start_point']
                rest_start_time = current_time
                rest_end_time = rest_start_time + datetime.timedelta(seconds=self.MIN_DAILY_REST)
                
                required_breaks.append({
                    'type': 'daily_rest',
                    'location': rest_location,
                    'start_time': rest_start_time,
                    'end_time': rest_end_time,
                    'duration': self.MIN_DAILY_REST,
                    'accumulated_distance': accumulated_distance
                })
                
                # Actualizar tiempos
                current_time = rest_end_time
                continuous_driving_time = 0
                daily_driving_time = 0
                last_break_time = rest_end_time
                last_daily_rest_time = rest_end_time
            
            # Actualizar tiempos para el siguiente segmento
            current_time += datetime.timedelta(seconds=segment_duration)
            continuous_driving_time += segment_duration
            daily_driving_time += segment_duration
            accumulated_distance += segment_distance
            
            # Añadir información de tiempo a cada segmento
            segment['start_time'] = current_time - datetime.timedelta(seconds=segment_duration)
            segment['end_time'] = current_time
        
        # Calcular tiempo total incluyendo descansos
        total_duration_with_breaks = (current_time - departure_time).total_seconds()
        
        # Calcular hora estimada de llegada
        estimated_arrival_time = current_time
        
        # Crear ruta mejorada
        enhanced_route = base_route.copy()
        enhanced_route.update({
            'departure_time': departure_time,
            'arrival_time': estimated_arrival_time,
            'duration_with_breaks': total_duration_with_breaks,
            'required_breaks': required_breaks
        })
        
        return enhanced_route
    
    def get_speed_limit(self, road_type: str, country_code: str) -> float:
        """
        Obtiene el límite de velocidad para un tipo de vía y país.
        
        Args:
            road_type: Tipo de vía
            country_code: Código de país ISO
            
        Returns:
            Límite de velocidad en km/h
        """
        if country_code in self.COUNTRY_SPEED_LIMITS and road_type in self.COUNTRY_SPEED_LIMITS[country_code]:
            return self.COUNTRY_SPEED_LIMITS[country_code][road_type]
        elif road_type in self.DEFAULT_SPEED_LIMITS:
            return self.DEFAULT_SPEED_LIMITS[road_type]
        else:
            return self.DEFAULT_SPEED_LIMITS['default']
    
    def find_rest_areas(self, route: Dict[str, Any], max_detour_distance: float = 5000) -> List[Dict[str, Any]]:
        """
        Encuentra áreas de descanso cercanas a la ruta.
        
        Args:
            route: Ruta calculada
            max_detour_distance: Distancia máxima de desvío permitida (en metros)
            
        Returns:
            Lista de áreas de descanso con información relevante
        """
        # En una implementación real, esta función consultaría una API o base de datos
        # para encontrar áreas de descanso cercanas a la ruta
        
        # Simulación de áreas de descanso
        rest_areas = []
        
        # Crear áreas de descanso simuladas a lo largo de la ruta
        segments = route['segments']
        for i, segment in enumerate(segments):
            if i % 2 == 0:  # Simular un área de descanso cada dos segmentos
                rest_area = {
                    'id': f'rest_area_{i}',
                    'name': f'Área de Descanso {i}',
                    'location': {
                        'lat': (segment['start_point']['lat'] + segment['end_point']['lat']) / 2,
                        'lng': (segment['start_point']['lng'] + segment['end_point']['lng']) / 2
                    },
                    'facilities': ['parking', 'toilets', 'restaurant'],
                    'distance_from_route': 0,  # En la ruta
                    'segment_index': i
                }
                rest_areas.append(rest_area)
        
        return rest_areas
    
    def optimize_rest_stops(self, route: Dict[str, Any], rest_areas: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Optimiza las paradas de descanso utilizando las áreas de descanso disponibles.
        
        Args:
            route: Ruta calculada con descansos requeridos
            rest_areas: Lista de áreas de descanso disponibles
            
        Returns:
            Ruta optimizada con paradas en áreas de descanso
        """
        optimized_route = route.copy()
        required_breaks = route['required_breaks']
        optimized_breaks = []
        
        # Para cada descanso requerido, encontrar el área de descanso más cercana
        for required_break in required_breaks:
            break_location = required_break['location']
            break_distance = required_break['accumulated_distance']
            
            # Encontrar áreas de descanso cercanas a la ubicación del descanso
            nearby_areas = []
            for area in rest_areas:
                # Calcular distancia aproximada entre el punto de descanso y el área
                area_location = area['location']
                distance = self._calculate_distance(
                    break_location['lat'], break_location['lng'],
                    area_location['lat'], area_location['lng']
                )
                
                # Si está lo suficientemente cerca, añadirla a las opciones
                if distance < 20000:  # 20 km
                    nearby_areas.append({
                        'area': area,
                        'distance': distance
                    })
            
            # Ordenar por distancia
            nearby_areas.sort(key=lambda x: x['distance'])
            
            # Si hay áreas cercanas, usar la más cercana
            if nearby_areas:
                best_area = nearby_areas[0]['area']
                optimized_break = required_break.copy()
                optimized_break['location'] = best_area['location']
                optimized_break['rest_area'] = best_area
                optimized_breaks.append(optimized_break)
            else:
                # Si no hay áreas cercanas, mantener el descanso original
                optimized_breaks.append(required_break)
        
        optimized_route['required_breaks'] = optimized_breaks
        return optimized_route
    
    def _calculate_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """
        Calcula la distancia entre dos puntos usando la fórmula de Haversine.
        
        Args:
            lat1: Latitud del punto 1
            lon1: Longitud del punto 1
            lat2: Latitud del punto 2
            lon2: Longitud del punto 2
            
        Returns:
            Distancia en metros
        """
        R = 6371000  # Radio de la Tierra en metros
        
        # Convertir coordenadas a radianes
        lat1_rad = math.radians(lat1)
        lon1_rad = math.radians(lon1)
        lat2_rad = math.radians(lat2)
        lon2_rad = math.radians(lon2)
        
        # Diferencias
        dlat = lat2_rad - lat1_rad
        dlon = lon2_rad - lon1_rad
        
        # Fórmula de Haversine
        a = math.sin(dlat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon/2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        distance = R * c
        
        return distance


# Ejemplo de uso
if __name__ == "__main__":
    # Crear instancia del calculador de rutas
    calculator = TruckRouteCalculator()
    
    # Definir origen y destino
    origin = {'lat': 40.4168, 'lng': -3.7038}  # Madrid
    destination = {'lat': 41.3851, 'lng': 2.1734}  # Barcelona
    
    # Definir parámetros del vehículo
    vehicle_params = {
        'height': 4.2,  # metros
        'width': 2.5,   # metros
        'length': 16.5, # metros
        'weight': 40,   # toneladas
        'axleCount': 5
    }
    
    # Calcular ruta
    route = calculator.calculate_route(
        origin=origin,
        destination=destination,
        vehicle_params=vehicle_params,
        departure_time=datetime.datetime.now()
    )
    
    # Encontrar áreas de descanso
    rest_areas = calculator.find_rest_areas(route)
    
    # Optimizar paradas de descanso
    optimized_route = calculator.optimize_rest_stops(route, rest_areas)
    
    # Imprimir resultados
    print(f"Distancia total: {optimized_route['distance'] / 1000:.1f} km")
    print(f"Duración sin descansos: {optimized_route['duration'] / 3600:.1f} horas")
    print(f"Duración con descansos: {optimized_route['duration_with_breaks'] / 3600:.1f} horas")
    print(f"Hora de salida: {optimized_route['departure_time']}")
    print(f"Hora estimada de llegada: {optimized_route['arrival_time']}")
    print("\nDescansos requeridos:")
    for i, break_info in enumerate(optimized_route['required_breaks']):
        print(f"  {i+1}. Tipo: {break_info['type']}")
        print(f"     Inicio: {break_info['start_time']}")
        print(f"     Fin: {break_info['end_time']}")
        print(f"     Duración: {break_info['duration'] / 60:.0f} minutos")
        if 'rest_area' in break_info:
            print(f"     Área de descanso: {break_info['rest_area']['name']}")
        print(f"     Distancia acumulada: {break_info['accumulated_distance'] / 1000:.1f} km")

